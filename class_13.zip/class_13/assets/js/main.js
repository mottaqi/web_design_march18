(function ($) {
	"use strict";

    jQuery(document).ready(function($){


        $(".embed-responsive iframe").addClass("embed-responsive-item");
        $(".carousel-inner .item:first-child").addClass("active");
        
        $('[data-toggle="tooltip"]').tooltip();
        
        
        $(".staff-list").owlCarousel({
            items: 4,
            loop: true,
            autoplay: true,
            nav: true,
            margin: 20,
            
        });



        


    });


    jQuery(window).load(function(){

        
    });


}(jQuery));	