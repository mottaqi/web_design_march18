(function ($) {
	"use strict";

    jQuery(document).ready(function($){


        $(".staff-list").owlCarousel({
            
             items: 1,
             loop:true,
             nav:true,
             autoplay: true,
             margin:30,
         });



        


    });


    jQuery(window).load(function(){

        
    });


}(jQuery));	